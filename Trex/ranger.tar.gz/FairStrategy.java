import trex.*;
/**
 * A simple example of extending the base Strategy.
 */

public class FairStrategy extends trex.Strategy {
  int bcount=0;

  public void init(Player jojo) {
    // call the initialization method of the superclass (base Strategy class)
    super.init(jojo);
    // do my own initialization stuff:
    // add my strategy to the choice menu
    boss.setValuation(TrexData.MAXPRICE);
  }

  public boolean bid() {
    boolean rval=false;
    boss.setValuation(TrexData.MAXPRICE);

    if( /* util(boss.anteBid()) <0 && */ bcount >= 98) {
      rval= boss.setBid(TrexData.MAXSTUFF/boss.market.NPlayers(),
			Math.min(boss.valuation(), boss.budget()/(TrexData.MAXSTUFF/boss.market.NPlayers())));
    }
    else
      rval= super.bid();
    
    if(rval) bcount++;
    return rval;
  }

  public void adapt(TrexBid igot) {
    System.out.println("I got "+igot.qty+","+igot.price+ " nbids ="+bcount);
    bcount=0;
    return;
  }
}



