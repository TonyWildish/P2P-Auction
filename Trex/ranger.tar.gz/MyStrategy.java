import trex.*;
/**
 * A simple example of extending the base Strategy.
 * This one adds "My Strategy" to the menu of choices.
 * "My Strategy" starts modestly, making a bid for it's "fair share".
 * Then based on what it does get, it adjusts the bid qty.
 * For more sophisticated strategies, you may want to use boss.market.bidlist
 * to see at all times the profile of your opponents' bids,
 * and the method util(TrexBid ) in this class to get the utility of 
 * a given bid before you actually set it.
 */

public class MyStrategy extends trex.Strategy {

  private double bidqty=TrexData.MAXSTUFF;
  private int round =0;

  public void init(Player jojo) {
    // call the initialization method of the superclass (base Strategy class)
    super.init(jojo);
    // do my own initialization stuff:
    // add my strategy to the choice menu
    choix.addItem("My Strategy");
    // make it the one selected by default
    choix.select("My Strategy");

  }


  /**
   * This is called by Player every playerInterval (default 1000ms)
   * to decide what to bid.
   */
  public boolean bid() {

        // initially bid for my fair share
    if(round==0) bidqty = TrexData.MAXSTUFF/boss.market.NPlayers();

    TrexBid tmpbid = new TrexBid();
    tmpbid.bidderid =  boss.market.getId();

    // if my strategy is not the one selected on the menu
    // call the bid function of the superclass
    if(choix.getSelectedItem() != "My Strategy")
      return super.bid();

    boss.market.addnews("... thinking-"+choix.getSelectedItem());

    tmpbid.price =  boss.valuation();
    
    tmpbid.qty = bidqty;

    return boss.setBid(tmpbid);

  }

  /**
   * This is called by TrexClient every time a RESULT is received, i.e
   * at the end of a round of bidding.
   * Use to do any strategy adaptation based on your allocation
   */
  public void adapt(TrexBid igot) {
    System.out.println("Adapting to "+igot.qty+","+igot.price);
    bidqty =  Math.min( boss.budget()/igot.price , TrexData.MAXSTUFF);
    round++;
  }

}



